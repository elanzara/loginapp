function NewsletterBlock() {

  return {
    templateUrl: 'views/templates/newsletterBlock.html'
  };

};


angular.module('elyweb').directive('newsletterBlock', NewsletterBlock);
