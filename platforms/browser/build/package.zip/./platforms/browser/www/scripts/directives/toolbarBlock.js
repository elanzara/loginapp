function ToolbarBlock() {

  return {
    templateUrl: 'views/templates/toolbarBlock.html'
  };

};


angular.module('elyweb').directive('toolbarBlock', ToolbarBlock);
