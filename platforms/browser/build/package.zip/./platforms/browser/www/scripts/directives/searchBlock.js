function SearchBlock() {

  return {
    templateUrl: 'views/templates/searchBlock.html'
  };

};


angular.module('elyweb').directive('searchBlock', SearchBlock);
