function FooterBlock() {

  return {
    templateUrl: 'views/templates/footerBlock.html'
  };

};


angular.module('elyweb').directive('footerBlock', FooterBlock);
